# TSO500-DRAGEN-pipeline
A DRAGEN pipeline for processing NovaSeq data produced by TruSight Oncology 500 HT (TSO500) sequencing chemistry. Full details for running the pipeline can be found in the BI SOP.

**To process data**

1. Activate the virtual environmment:
```
source /staging/venvs/tso-500-dragen-pipeline/bin/activate
```
2. Move to the correct working directory:
```
cd /staging/TSO500-dragen/
```
3. Run the pipeline using screen:
```
screen -L python /staging/TSO500-DRAGEN-pipeline-v1.0.0/TSO500-Dragen-pipeline.py -c <config_file> -run <run_folder> 
-n <named_worksheet> -out <output_directory>
```
**Example**
```
nohup python /staging/TSO500-DRAGEN-pipeline-v1.0.0/TSO500-Dragen-pipeline.py -c /staging/TSO500-DRAGEN-pipeline-v1.0.0/TSO500-config.txt -run /NovaSeq_data_storage/990101_A12345_0123_AH5WJBDRX2/ -n 123456 -out /pipeline_output/build37/
```
**Dependencies**

- Illumina DRAGEN Bio-IT Platform v3.10
- bcftools-1.15.1
- deepTools-3.5.1
All results have been generated using DRAGEN Bio-IT Platform v3.10.8 - we have very recently moved across from a v3 to v4 DRAGEN server but the underlying software version has not changed. 
